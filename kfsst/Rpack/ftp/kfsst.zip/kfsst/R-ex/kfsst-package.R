### Name: kfsst-package
### Title: Kalman Filter tracking including Sea Surface Temperature
### Aliases: kfsst-package
### Keywords: package models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



