### Name: blue.shark
### Title: A track of a blue shark released near Hawai'i
### Aliases: blue.shark
### Keywords: datasets

### ** Examples

  data(blue.shark)
  sst.path<-get.sst.from.server(blue.shark)
  sst.file<-write.sst.field(sst.path)
  fit<-kfsst(blue.shark, sst.file, bx.active=FALSE, bsst.active=FALSE)
  fit
  plot(fit, ci=TRUE, pred=FALSE)



