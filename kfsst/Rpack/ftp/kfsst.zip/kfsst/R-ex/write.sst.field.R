### Name: write.sst.field
### Title: Writes a smoothed version of the SST-field to a file
### Aliases: write.sst.field
### Keywords: models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



