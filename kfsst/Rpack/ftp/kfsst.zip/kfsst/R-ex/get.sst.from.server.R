### Name: get.sst.from.server
### Title: Get SST-field from server
### Aliases: get.sst.from.server
### Keywords: models

### ** Examples

  # No example supplied here, but check out the example 
  # in the blue.shark dataset documentation



