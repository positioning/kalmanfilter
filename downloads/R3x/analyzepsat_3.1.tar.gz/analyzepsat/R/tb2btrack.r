
# function to extract a corrected track from tagbase. Temp/depth not included

tb2btrack = function(tb, tagid, is.ptt = F){
	require(RODBC)
	con = odbcConnectAccess(tb)
	print(paste("building btrack for Tag# ", tagid, sep = ""))

	if(is.ptt==T){
		taginfo = sqlFetch(con, "TagInfo")
		attach(taginfo)
		tagidx = TagPTTID == pttid
		tagid = TagID[tagidx]
	}

	track = sqlQuery(con, paste('select * from track where TagID = ', tagid, sep = ""))
	track$Year = as.numeric(format(track$SDate,'%Y')) 
	track$Month = as.numeric(format(track$SDate,'%m')) 
	track$Day = as.numeric(format(track$SDate,'%d')) 

	varx =  sqlQuery(con, paste('select * from Analysis_Outputs where ParameterID=204 AND TagID = ', tagid, sep=""))
	vary =  sqlQuery(con, paste('select * from Analysis_Outputs where ParameterID=205 AND TagID = ', tagid, sep=""))
	covxy =  sqlQuery(con, paste('select * from Analysis_Outputs where ParameterID=208 AND TagID = ', tagid, sep=""))

if(length(covxy[,1])==0){
covxy = data.frame(ParameterValue= rep(0, nrow(varx)))
# covxy$ParameterValue = rep(0, nrow(varx))
}
	
	dat = data.frame(Year = track$Year, Month = track$Month, Day = track$Day, V11 = varx$ParameterValue, V12 = covxy$ParameterValue, V21 = covxy$ParameterValue, V22 = vary$ParameterValue, Lon = track$Lon, Lat = track$Lat)
	dat
}
