\name{get.min3}
\Rdversion{1.1}
\alias{get.min3}
%- Also NEED an '\alias' for EACH other topic documented here.
\title{
%%  ~~function to do ... ~~
}
\description{
%%  ~~ A concise (1-5 lines) description of what the function does. ~~
}
\usage{
get.min3(lon1, lat1, lon2, lat2, lon3, lat3, samp)
}
%- maybe also 'usage' for other objects documented here.
\arguments{
  \item{lon1}{
%%     ~~Describe \code{lon1} here~~
}
  \item{lat1}{
%%     ~~Describe \code{lat1} here~~
}
  \item{lon2}{
%%     ~~Describe \code{lon2} here~~
}
  \item{lat2}{
%%     ~~Describe \code{lat2} here~~
}
  \item{lon3}{
%%     ~~Describe \code{lon3} here~~
}
  \item{lat3}{
%%     ~~Describe \code{lat3} here~~
}
  \item{samp}{
%%     ~~Describe \code{samp} here~~
}
}
\details{
%%  ~~ If n