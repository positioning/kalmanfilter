.First.lib<-function(libname,pkgname)
    library.dynam("ncdf",pkgname,libname)


