`get.sst.from.server` <-
function (track, folder = tempdir(), server = "http://atlas.nmfs.hawaii.edu/cgi-bin/reynolds_extract.py") 
{
    fl <- dir(folder)
    if (length(fl) != 0) {
        folder <- paste(folder, "sst_temp", sep = "/")
        dir.create(folder)
    }
    if (is.data.frame(track)) 
        track <- list(track)
    minDate <- min(unlist(lapply(track, function(x) mdy.date(x[1, 
        2], x[1, 1], x[1, 3]))))
    maxDate <- max(unlist(lapply(track, function(x) mdy.date(x[nrow(x), 
        2], x[nrow(x), 1], x[nrow(x), 3]))))
    minDate <- minDate - 10
    maxDate <- maxDate + 10
    yrRan <- c(date.mdy(minDate)$year, date.mdy(maxDate)$year)
    daysIntoYearRan <- c(minDate - mdy.date(1, 1, yrRan[1]), 
        maxDate - mdy.date(1, 1, yrRan[2]))
    minLon <- min(unlist(lapply(track, function(x) min(x[, 4])))) - 
        1
    maxLon <- max(unlist(lapply(track, function(x) max(x[, 4])))) + 
        1
    lonRan <- c(minLon, maxLon)
    minLat <- min(unlist(lapply(track, function(x) min(x[, 5])))) - 
        1
    maxLat <- max(unlist(lapply(track, function(x) max(x[, 5])))) + 
        5
    latRan <- c(minLat, maxLat)
    string <- ""
    string <- paste(string, "?lon1=", lonRan[1], "&lon2=", lonRan[2], 
        sep = "")
    string <- paste(string, "&lat1=", latRan[1], "&lat2=", latRan[2], 
        sep = "")
    string <- paste(string, "&year1=", yrRan[1], "&day1=", daysIntoYearRan[1], 
        sep = "")
    string <- paste(string, "&year2=", yrRan[2], "&day2=", daysIntoYearRan[2], 
        sep = "")
    link <- paste(server, string, sep = "")
    dest <- paste(folder, "temp.zip", sep = "/")
    download.file(link, dest, mode = "wb")
    .Internal(int.unzip(paste(folder, "temp.zip", sep = "/"), 
        NULL, folder))
    unlink(paste(folder, "temp.zip", sep = "/"))
    cat(paste(rep("=", options()$width), collapse = ""), "\n\n")
    cat("Downloaded", length(dir(folder)), "files to:\n\n  ", 
        folder)
    cat("\n\nNow you most likely want to run a command like:\n\n   ")
    cat(paste("sst.file <- write.sst.field(datadir='", folder, 
        "', filename='sst.dat')", sep = ""), "\n\n")
    cat("to generate the smooth representation of the SST-field and its\n")
    cat("derivatives and save it in the file called 'sst.dat'\n\n")
    cat("Please consult the documentation (by typing '?write.sst.field') \n")
    cat("for a description of the different options including degree of\n")
    cat("smoothing and resolution of representation.\n\n")
    cat(paste(rep("=", options()$width), collapse = ""), "\n\n")
    return(folder)
}
