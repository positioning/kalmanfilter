`write.sst.field` <-
function (datadir, nlon = 100, nlat = 150, filename = "sst.dat", 
    alpha = 0.05, from.ystr = c(3, 6), from.dstr = c(7, 9), to.ystr = c(11, 
        14), to.dstr = c(15, 17), peak = FALSE) 
{
    mydig <- 8
    dirlist <- dir(datadir)
    greg.zero.date <- mdy.date(day = 15, month = 10, year = 1582)
    from <- mdy.date(day = 1, month = 1, year = as.numeric(substr(dirlist, 
        from.ystr[1], from.ystr[2])))
    from <- from + as.numeric(substr(dirlist, from.dstr[1], from.dstr[2])) - 
        1 - greg.zero.date
    to <- mdy.date(day = 1, month = 1, year = as.numeric(substr(dirlist, 
        to.ystr[1], to.ystr[2])))
    to <- to + as.numeric(substr(dirlist, to.dstr[1], to.dstr[2])) - 
        1 - greg.zero.date
    grid.greg <- 0.5 * (from + to)
    ngreg <- length(grid.greg)
    dat <- read.table(paste(datadir, dirlist[1], sep = "/"), 
        header = FALSE)
    x <- dat[, 2]
    y <- dat[, 1]
    z <- dat[, 3]
    grid.x <- seq(min(x), max(x), length = nlon)
    grid.y <- seq(min(y), max(y), length = nlat)
    grid <- expand.grid(grid.x, grid.y)
    cat("", file = filename)
    cat(ngreg, "\n", nlon, "\n", nlat, "\n", file = filename, 
        append = TRUE)
    cat(grid.greg, "\n", file = filename, append = TRUE)
    cat(grid.x, "\n", file = filename, append = TRUE)
    cat(grid.y, "\n", file = filename, append = TRUE)
    cat("\nStep 1/3:")
    for (file in dirlist) {
        dat <- read.table(paste(datadir, file, sep = "/"), header = FALSE)
        x <- dat[, 2]
        y <- dat[, 1]
        z <- dat[, 3]
        sst <- locfit(z ~ x:y, alpha = alpha)
        grid.sst <- matrix(predict(sst, newdata = as.matrix(grid)), 
            ncol = nlon, nrow = nlat, byrow = TRUE)
        if (peak) {
            par(mfrow = c(1, 2))
            ny <- length(unique(y))
            nx <- length(unique(x))
            mat <- matrix(z, nrow = ny, ncol = nx, byrow = TRUE)
            image(unique(x), unique(y)[ny:1], t(mat[ny:1, ]), 
                xlab = "Longitude", ylab = "Latitude", main = "Raw")
            contour(unique(x), unique(y)[ny:1], t(mat[ny:1, ]), 
                add = TRUE)
            image(grid.x, grid.y, t(grid.sst), xlab = "Longitude", 
                ylab = "Latitude", main = "Smoothed")
            contour(grid.x, grid.y, t(grid.sst), add = TRUE)
            dummy <- readline("Press return to see next\n")
            par(mfrow = c(1, 1))
        }
        write.table(round(grid.sst, mydig), file = filename, 
            append = TRUE, quote = FALSE, row.names = FALSE, 
            col.names = FALSE)
        cat(".")
        .myflush()
    }
    cat("\nStep 2/3:")
    for (file in dirlist) {
        dat <- read.table(paste(datadir, file, sep = "/"), header = FALSE)
        x <- dat[, 2]
        y <- dat[, 1]
        z <- dat[, 3]
        sst.dx <- locfit(z ~ x:y, deriv = 1, alpha = alpha)
        grid.sst.dx <- matrix(predict(sst.dx, newdata = as.matrix(grid)), 
            ncol = nlon, nrow = nlat, byrow = TRUE)
        write.table(round(grid.sst.dx, mydig), file = filename, 
            append = TRUE, quote = FALSE, row.names = FALSE, 
            col.names = FALSE)
        cat(".")
        .myflush()
    }
    cat("\nStep 3/3:")
    for (file in dirlist) {
        dat <- read.table(paste(datadir, file, sep = "/"), header = FALSE)
        x <- dat[, 2]
        y <- dat[, 1]
        z <- dat[, 3]
        sst.dy <- locfit(z ~ x:y, deriv = 2, alpha = alpha)
        grid.sst.dy <- matrix(predict(sst.dy, newdata = as.matrix(grid)), 
            ncol = nlon, nrow = nlat, byrow = TRUE)
        write.table(round(grid.sst.dy, mydig), file = filename, 
            append = TRUE, quote = FALSE, row.names = FALSE, 
            col.names = FALSE)
        cat(".")
        .myflush()
    }
    cat("\n\n")
    ow <- getwd()
    setwd(dirname(filename))
    filename <- file.path(getwd(), basename(filename))
    setwd(ow)
    cat(paste(rep("=", options()$width), collapse = ""), "\n\n")
    cat("The smoothed field and its derivatives is now saved in the\n")
    cat("file", paste("'", filename, "'.", sep = ""), "\n\n")
    cat("This filename should be given as the second argument to the\n")
    cat("'kfsst' function (first argument is the track). For example:\n\n")
    cat(paste("   fit<-kfsst(track1, sst.file='", filename, "')", 
        sep = ""), "\n\n")
    cat("The function 'kfsst' fits the default full model. It is\n")
    cat("possible and in some cases necessary to customize the full\n")
    cat("model, for instance by choosing a simpler variance structure,\n")
    cat("or leaving out a bias term. For details on these and other\n")
    cat("options, please see the documentation (?kfsst).\n\n")
    cat(paste(rep("=", options()$width), collapse = ""), "\n\n")
    return(path.expand(filename))
}
